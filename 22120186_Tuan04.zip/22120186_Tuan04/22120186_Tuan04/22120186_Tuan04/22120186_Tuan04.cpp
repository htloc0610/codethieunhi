#include"Header.h"

int main()
{
	ifstream input("DS_hoc_sinh.csv");
	if (input.is_open())
	{
		int n = ReadMem(input);
		input.seekg(0, 0);
		HocSinh * a = new HocSinh[n];
		ReadFile(input, a);
		for (int i = 0; i < n; i++)
		{
			cout << a[i].MaSo << "\t" << a[i].HoTen << "\t" << a[i].Diem[0] << " " << a[i].Diem[1] << " " << a[i].Diem[2] << endl;
		}
		HocSinh* Q1 = new HocSinh[MemOfQ1(a, n)];
		HocSinh* Q2 = new HocSinh[MemOfQ2(a, n)];
		SetMem(Q1, Q2, a, n);
		Sort(Q1, MemOfQ1(a, n));
		ReadFile(Q1, MemOfQ1(a, n), "DS_hoc_sinh_gioi.csv");
		Sort(Q2, MemOfQ2(a, n));
		ReadFile(Q2, MemOfQ2(a, n), "DS_hoc_sinh_kem.csv");
		input.close();
		delete[] a;
		delete[] Q1;
		delete[] Q2;
	}
	else
	{
		cout << "Khong doc duoc file";
	}
	return 0;
}