#pragma once
#include<iostream>
#include<string>
#include<fstream>
using namespace std;

typedef struct HS
{
	char MaSo[8];
	char HoTen[20];
	float Diem[3]; //To�n, L�, H�a
} HocSinh;

int ReadMem(ifstream& input);

void ReadFile(ifstream& input, HocSinh* a);

float DTB(HocSinh a);

int MemOfQ1(HocSinh* a, int n);

int MemOfQ2(HocSinh* a, int n);

void SetMem(HocSinh* Q1, HocSinh* Q2, HocSinh* a, int n);

void Sort(HocSinh* a, int n);

void ReadFile(HocSinh* a, int n, string s);